<?php

if (!defined('ABSPATH')) {
	die('-1');
}
class WPBakeryShortCode_G5Plus_Pricing extends G5Plus_ShortCode {

}
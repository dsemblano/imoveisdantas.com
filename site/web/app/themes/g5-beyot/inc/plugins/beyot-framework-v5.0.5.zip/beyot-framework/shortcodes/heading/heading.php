<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 5/17/2016
 * Time: 1:54 PM
 */
if (!defined('ABSPATH')) {
    die('-1');
}
class WPBakeryShortCode_G5Plus_Heading extends G5Plus_ShortCode {

}
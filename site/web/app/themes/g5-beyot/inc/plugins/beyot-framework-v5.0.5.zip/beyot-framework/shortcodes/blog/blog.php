<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 4/6/2016
 * Time: 3:59 PM
 */
if (!defined('ABSPATH')) {
	die('-1');
}
class WPBakeryShortCode_G5Plus_Blog extends G5Plus_ShortCode {

}
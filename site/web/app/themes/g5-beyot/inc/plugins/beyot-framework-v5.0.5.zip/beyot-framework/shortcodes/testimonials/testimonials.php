<?php
/**
 * Created by PhpStorm.
 * User: Kaga
 * Date: 15/9/2016
 * Time: 10:52 AM
 */
if (!defined('ABSPATH')) {
	die('-1');
}
class WPBakeryShortCode_G5Plus_Testimonials extends G5Plus_ShortCode {

}
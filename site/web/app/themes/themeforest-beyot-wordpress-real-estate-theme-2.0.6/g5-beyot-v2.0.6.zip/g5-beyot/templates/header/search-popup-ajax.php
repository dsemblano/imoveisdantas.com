<div id="search_popup_wrapper" data-search="ajax" class="popup-overlay-wrapper" data-ajax-action="result_search">
	<div class="popup-overlay-content search-ajax-content">
		<input type="text" value="" placeholder="<?php esc_html_e('Type at least 3 characters to search','g5-beyot'); ?>"/>
		<div class="search-button" data-search-wrapper="#search_popup_wrapper"><i class="fa fa-search"></i></div>
		<div class="popup-overlay-result search-ajax-result"></div>
	</div>
	<a href="#" class="close-button transition03 prevent-default" data-ref="#search_popup_wrapper"><i class="fa fa-close"></i></a>
</div>
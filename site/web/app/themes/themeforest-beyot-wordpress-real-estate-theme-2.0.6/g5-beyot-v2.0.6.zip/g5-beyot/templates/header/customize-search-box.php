<?php
/**
 * Return search form
 */
get_search_form();